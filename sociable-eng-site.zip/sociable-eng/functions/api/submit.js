// Cloudflare Pages Function: /api/submit
// Приймає заявку з форми на сайті та надсилає її у Telegram-чат через бота.
//
// НАЛАШТУВАННЯ (Cloudflare Pages → Settings → Environment variables):
//   TELEGRAM_BOT_TOKEN  — токен бота, отриманий від @BotFather
//   TELEGRAM_CHAT_ID    — ID чату/групи, куди приходитимуть заявки
//
// Як отримати CHAT_ID:
//   1. Створіть бота через @BotFather, збережіть токен
//   2. Додайте бота у ваш чат/групу (або напишіть йому в особисті)
//   3. Напишіть будь-яке повідомлення в цей чат
//   4. Відкрийте https://api.telegram.org/bot<TOKEN>/getUpdates
//   5. Знайдіть "chat":{"id": ... } — це і є CHAT_ID

export async function onRequestPost(context) {
  const { request, env } = context;

  try {
    const data = await request.json();

    const name = (data.name || '').toString().slice(0, 200);
    const phone = (data.phone || '').toString().slice(0, 200);
    const format = (data.format || '').toString().slice(0, 200);
    const comment = (data.comment || '').toString().slice(0, 1000);
    const source = (data.source || 'сайт').toString().slice(0, 200);

    if (!name || !phone) {
      return new Response(JSON.stringify({ ok: false, error: 'missing_fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const text =
      `📩 Нова заявка — Sociable.eng\n\n` +
      `👤 Ім'я: ${name}\n` +
      `📞 Контакт: ${phone}\n` +
      `📚 Формат: ${format || '—'}\n` +
      (comment ? `💬 Коментар: ${comment}\n` : '') +
      `🌐 Джерело: ${source}`;

    const tgUrl = `https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`;
    const tgRes = await fetch(tgUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: env.TELEGRAM_CHAT_ID,
        text: text
      })
    });

    if (!tgRes.ok) {
      const errText = await tgRes.text();
      return new Response(JSON.stringify({ ok: false, error: 'telegram_failed', detail: errText }), {
        status: 502,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: 'server_error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
